
// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;

dwr.engine._defaultPath = '/blog/dwr';

if (Pebble == null) var Pebble = {};
Pebble._path = '/blog/dwr';
Pebble.previewComment = function(p0, p1, callback) {
  dwr.engine._execute(Pebble._path, 'Pebble', 'previewComment', p0, p1, callback);
}
Pebble.saveComment = function(p0, p1, callback) {
  dwr.engine._execute(Pebble._path, 'Pebble', 'saveComment', p0, p1, callback);
}
